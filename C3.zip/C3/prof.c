#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

int x = 0;
int y = 0;
pthread_mutex_t lock1, lock2;

void *RandomSUm(void *arg){

	for (int i = 0; i < 100; ++i)
	{
		pthread_mutex_lock(&lock1);
		x += (rand() % 100);
		y += (rand() % 100);
		pthread_mutex_unlock(&lock2);
	}
	return NULL;
}

void *Verify(void *arg){
	for (int i = 0; i < 100; ++i)
	{
		pthread_mutex_lock(&lock2);
		if(x > y)
			printf("valor de x(%d) maior que y(%d).\n", x, y);
		pthread_mutex_unlock(&lock1);
	}
	return NULL;
}

int main(int argc, char const *argv[])
{
	srand(time(NULL));	//Seed para numeros random
	pthread_t lmao, eksde;
	pthread_mutex_init(&lock1, NULL);
	pthread_create(&lmao, NULL, RandomSUm, NULL);
	pthread_create(&eksde, NULL, Verify, NULL);

	pthread_join(lmao, NULL);
	pthread_join(eksde, NULL);

	return 0;
}

/*

criar um programa em C onde  vamos ter 2 threads e manipulam 1 variavel global(incializada a 1)
1 thread increment
2 thread decrement
cada uma faz isso 5 vezes
imprimir o resultado
*/