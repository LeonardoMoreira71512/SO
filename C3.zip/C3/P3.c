#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

char information;
int InfoCheck = 0;

void setInformation(char set){
	while(InfoCheck);
	information = set;
	InfoCheck = 1;
}

char readInformation(void){
	while(!InfoCheck);
	char out = information;
	InfoCheck = 0;
	return out;
}


void *Thread_Read(void *arg){
	char in;
	while(scanf("%c", &in) != EOF && in != 'X'){
		setInformation(in);
	}
	printf("\nReadThread Stopped\n");
	setInformation('X');
	return NULL;
}

void *Thread_Write(void *arg){
	char out = '\0';
	while((out = readInformation()) != 'X' ){
		printf("%c", out);
	}
	printf("WriteThread Stopped\n");
	return NULL;
}

int main(int argc, char const *argv[])
{
	pthread_t ThreadRead, ThreadWrite;

	pthread_create(&ThreadRead, NULL, Thread_Read, NULL);
	pthread_create(&ThreadWrite, NULL, Thread_Write, NULL);

	pthread_join(ThreadRead, NULL);
	pthread_join(ThreadWrite, NULL);

	return 0;
}