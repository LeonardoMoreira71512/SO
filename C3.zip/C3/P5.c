#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

double **A;
int linha_A, coluna_A;
double **B;
int linha_B, coluna_B;
double **result;
int n_threads;


void *MultiThreadProduct(void *arg){
	long ID = (long) arg;
	int LinesToCalc = ceil( (linha_A*1.0)/n_threads );
	int LineStart = ID * LinesToCalc;
	for (int i = LineStart; i < linha_A && i < (LineStart + LinesToCalc); ++i){
		for (int j = 0; j < coluna_B; j++){
			for (int k = 0; k < coluna_A; k++){
				result[i][j] += A[i][k] * B[k][j];
			}
		}
	}

	return NULL;
}

double **AlocateMatriz(int line, int column){
	double **a = (double **)malloc(line * sizeof(double *));
	for (int i = 0; i < line; ++i)
		a[i] = (double *)calloc(column, sizeof(double));
	return a;
}

double **AlocateAndReadMatriz(int line, int column){
	double **a = (double **)malloc(line * sizeof(double *));
	double *temp = malloc(sizeof(double)*line*column);
	printf("Introduzir valores para a matriz...\n");
	double ReadValue;
	for (int i = 0; i < line*column; ++i){
		scanf("%lf", &ReadValue);
		temp[i] = ReadValue;
	}
	for (int i = 0; i < line; ++i)
		a[i] = temp + (i * column);
	return a;
}

void PrintMatriz(double **a, int line, int column){
	for (int i = 0; i < line; ++i){
		printf("%f", a[i][0]);
		for (int j = 1; j < column; ++j){
			printf(" %f", a[i][j]);
		}
		printf("\n");
	}
}

int main(int argc, char const *argv[])
{
	printf("Ler dimensões matriz A\n");
	scanf("%d %d", &linha_A, &coluna_A);
	A = AlocateAndReadMatriz(linha_A, coluna_A);

	printf("Ler dimensões matriz B\n");
	scanf("%d %d", &linha_B, &coluna_B);
	if(coluna_A != linha_B){
		printf("Matrizes não são validas para multiplicação\n");
		exit(0);
	}
	B = AlocateAndReadMatriz(linha_B, coluna_B);

	result = AlocateMatriz(linha_A, coluna_B);

	printf("Numero de threads a utilizar:\n");
	scanf("%d", &n_threads);
	pthread_t Threads[n_threads];

	for (long i = 0; i < n_threads; ++i){
		pthread_create(&Threads[i], NULL, MultiThreadProduct, (void *)i);
	}

	for (int i = 0; i < n_threads; ++i){
		pthread_join(Threads[i], NULL);
	}

	printf("Matriz A:\n");
	PrintMatriz(A, linha_A, coluna_A);
	printf("Matriz B:\n");
	PrintMatriz(B, linha_B, coluna_B);
	printf("Matriz A*B:\n");
	PrintMatriz(result, linha_A, coluna_B);


	return 0;
}