#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
pthread_mutex_t lock;

void *work(void *arg){
	long id = (long) arg;
	int dur = rand() % 1001;

	printf("ID nº%ld, vai dormir.\n", id);
	pthread_mutex_unlock(&lock);
	usleep(dur);
	printf("ID nº%ld acordou apos %d ms.\n", id, dur);

	return NULL;
}

void *createAndWait(void *arg){
	long n_threads = (long)arg;
	pthread_t Threads[n_threads];

	for (long i = 0; i < n_threads; ++i){
		pthread_mutex_lock(&lock);
		pthread_create(&Threads[i], NULL, work, (void *) i);
	}

	for (long i = 0; i < n_threads; ++i)
		pthread_join(Threads[i], NULL);
	return NULL;
}

int main(int argc, char const *argv[])
{
	srand(time(NULL));	//Seed para numeros random
	pthread_t Thread;
	long n_threads;
	scanf( "%ld", &n_threads );

	pthread_create(&Thread, NULL, createAndWait, (void *) n_threads);
	pthread_join(Thread, NULL);

	return 0;
}