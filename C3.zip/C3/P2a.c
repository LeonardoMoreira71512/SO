#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

void *work(void *arg){
	long id = (long) arg;
	int dur = rand() % 1001;

	printf("ID nº%ld, vai dormir.\n", id);
	usleep(dur);
	printf("ID nº%ld acordou apos %d ms.\n", id, dur);

	return NULL;
}

int main(int argc, char const *argv[])
{
	srand(time(NULL));	//Seed para numeros random
	pthread_t Thread;
	long id;
	scanf( "%ld", &id );

	pthread_create(&Thread, NULL, work, (void *) id);
	pthread_join(Thread, NULL);

	return 0;
}