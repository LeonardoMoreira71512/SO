#include <stdio.h>
#include <pthread.h>

const char *Message = "Mensagem da thread nº";
pthread_mutex_t lock;

void *PrintMessage(void *arg){
	long id = (long) arg;

	pthread_mutex_lock(&lock);
	for (int i = 0; Message[i] != '\0'; ++i)
		printf("%c", Message[i]);
	printf("%ld\n", id);
	pthread_mutex_unlock(&lock);

	return NULL;
}

int main(int argc, char const *argv[])
{
	pthread_t Threads[5];
	pthread_mutex_init(&lock, NULL);
	for (long i = 0; i < 5; ++i)
		pthread_create(&Threads[i], NULL, PrintMessage, (void *) i);

	for (int i = 0; i < 5; ++i)
		pthread_join(Threads[i], NULL);

	return 0;
}