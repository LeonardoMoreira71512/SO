#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>

pthread_t *Threads;
sem_t *Semaphores;

typedef struct{
	long ClientID;
	int SemID;
}ThreadInfo;

ThreadInfo * infoBuilder(long ClientID, int SemID){
	ThreadInfo *result = malloc(sizeof(ThreadInfo));
	result->ClientID = ClientID;
	result->SemID = SemID;
	return result;
}

void *Lavandaria(void *arg){
	ThreadInfo *info = (ThreadInfo *) arg;
	int dur = rand() % 10;
	printf("ClientID<%ld> ThreadID<%d> vai dormir durante <%d>s...\n", info->ClientID, info->SemID, dur);
	sleep(dur);
	//free(info); // Segmentation Fault ????
	sem_post(&Semaphores[info->SemID]);
	return NULL;
}

int main(int argc, char const *argv[]){
	srand(time(NULL));	//Seed para numeros random
	int MaxInside;
	printf("Introduza numero maximo de pessoas dentro da lavandaria\n");
	scanf("%d", &MaxInside);
	Threads = (pthread_t *)malloc(sizeof(pthread_t)*MaxInside);
	Semaphores = (sem_t *)malloc(sizeof(sem_t)*MaxInside);
	for (int i = 0; i < MaxInside; ++i)
		sem_init(&Semaphores[i], 0, 1);
	int entrada = 0;
	long ID = 0;
	printf("Pessoas a entrar: ( <= 0 fecha o programa )\n");
	while(1){
		scanf("%d", &entrada);
		if(entrada <= 0) break;
		printf("%d Pessoas a entrar na lavandaria...\n", entrada);
		while(entrada != 0){
			for (int i = 0; i < MaxInside; ++i){
				if(entrada == 0) break;
				else if(sem_trywait(&Semaphores[i]) == 0){
					ThreadInfo *SendInformation = infoBuilder( ID, i);
					ID++;
					entrada--;
					pthread_create(&Threads[i], NULL, Lavandaria, (void *)SendInformation);
				}
			}
			usleep(50); //esperar 50ms antes de verificar novamente para não gastar recursos
		}
	}
	printf("A fechar lavandaria...\n");
	for (int i = 0; i < MaxInside; ++i){
		pthread_join(Threads[i], NULL);
		sem_destroy(&Semaphores[i]);
	}
	free(Threads);
	free(Semaphores);
	printf("Lavandaria fechada.\n");
	return 0;
}